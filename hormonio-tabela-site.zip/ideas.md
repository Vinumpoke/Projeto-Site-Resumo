# Ideias de Design — Tabela Hormonal Interativa

## Contexto
Aplicação acadêmica/científica com tabela relacional de hormônios humanos. O público é estudantes e profissionais de saúde. A interface precisa ser densa em informação, mas navegável e esteticamente refinada.

---

<response>
<text>
## Ideia 1 — "Atlas Científico Moderno"

**Design Movement:** Scientific Data Visualization meets Editorial Design (inspirado em revistas como Nature e Scientific American)

**Core Principles:**
1. Hierarquia tipográfica rigorosa — títulos serifados contrastam com dados em sans-serif monoespaçado
2. Densidade informacional controlada — tabela rica mas respirável com espaçamento generoso
3. Codificação cromática por sistema endócrino — cada eixo (hipotalâmico, tireoidiano, etc.) tem sua cor
4. Interatividade funcional — filtros, busca e destaque de relações

**Color Philosophy:** Fundo off-white (papel científico), texto carvão escuro, acentos em azul-teal profundo (#0F5F7A) para hipotálamo, âmbar para suprarrenal, verde-musgo para pâncreas, lilás para reprodutor. Cores transmitem seriedade acadêmica com distinção visual.

**Layout Paradigm:** Sidebar fixa com navegação por sistema endócrino + área principal com tabela horizontal scrollável. Header com estatísticas (total de hormônios, sistemas, etc.).

**Signature Elements:**
1. Tags coloridas por sistema endócrino em cada linha da tabela
2. Ícones anatômicos minimalistas (osso, rim, fígado) como cabeçalhos das colunas de efeitos
3. Indicadores visuais de retroalimentação (seta circular verde = positiva, seta circular vermelha = negativa)

**Interaction Philosophy:** Clicar em uma linha expande detalhes; hover destaca relações entre hormônios; filtros por sistema/órgão-alvo

**Animation:** Fade-in suave das linhas da tabela (stagger 30ms), expansão fluida de detalhes (200ms ease-out), transição de cor no hover (150ms)

**Typography System:** Títulos em Playfair Display (serifado, autoridade), dados em IBM Plex Sans (legibilidade técnica), valores/códigos em IBM Plex Mono
</text>
<probability>0.08</probability>
</response>

<response>
<text>
## Ideia 2 — "Dashboard Clínico Dark"

**Design Movement:** Medical Dashboard / Dark Mode Data Interface (inspirado em sistemas hospitalares modernos como Epic e interfaces de monitoramento)

**Core Principles:**
1. Fundo escuro com alto contraste para leitura prolongada
2. Dados apresentados em cards modulares com bordas sutis
3. Visualizações inline (mini-barras de intensidade de efeito)
4. Filtros e busca proeminentes no topo

**Color Philosophy:** Fundo #0D1117 (quase preto), superfícies #161B22, texto #E6EDF3. Acentos: ciano #58A6FF para hipotálamo/hipófise, laranja #F0883E para suprarrenal, verde #3FB950 para pâncreas, rosa #FF7B72 para reprodutor.

**Layout Paradigm:** Full-width com sticky header de filtros, tabela com linhas zebradas sutis, colunas fixas para nome e sistema

**Signature Elements:**
1. Badges coloridos por sistema com ícone de glândula
2. Células com indicadores de intensidade (ponto colorido = efeito presente/ausente)
3. Painel lateral de detalhes deslizante ao clicar

**Interaction Philosophy:** Interface de "exploração" — o usuário navega como em um banco de dados clínico

**Animation:** Slide-in do painel de detalhes (250ms), pulse sutil em badges ao filtrar

**Typography System:** Space Grotesk para títulos (geométrico, tecnológico), Inter para corpo, JetBrains Mono para dados técnicos
</text>
<probability>0.07</probability>
</response>

<response>
<text>
## Ideia 3 — "Enciclopédia Viva" ✅ ESCOLHIDA

**Design Movement:** Neoclassical Scientific Encyclopedia meets Interactive Web App

**Core Principles:**
1. Fundo levemente texturizado (papel pergaminho digital) com elementos gráficos anatômicos sutis
2. Tipografia editorial com serifa para títulos e sans-serif humanista para conteúdo
3. Sistema de cores quentes e frias por categoria hormonal
4. Tabela como "mapa" navegável — não apenas lista, mas sistema relacional visual

**Color Philosophy:** Fundo creme/marfim (#FAFAF7), bordas em sépia suave. Paleta de acentos: índigo profundo (#3B3F8C) para hipotálamo/hipófise, terracota (#C4622D) para suprarrenal, verde-azulado (#2A7A6F) para pâncreas/metabolismo, violeta (#6B4FA0) para reprodutor, azul-aço (#2C5F8A) para tireoide/mineral. Transmite autoridade enciclopédica com calor visual.

**Layout Paradigm:** Header editorial com título e estatísticas. Barra de controles (filtro por sistema, busca, toggle de colunas). Tabela principal com scroll horizontal e linhas expansíveis. Sem sidebar — foco total na tabela.

**Signature Elements:**
1. Cabeçalho de seção com linha decorativa e nome do sistema endócrino em destaque
2. Células de retroalimentação com ícones de seta circular (↻ verde = positiva, ↺ vermelho = negativa)
3. Efeitos em órgãos representados por ícones + texto curto, com tooltip expandido

**Interaction Philosophy:** Cada linha é expansível para ver detalhes completos; filtros por sistema e órgão-alvo; busca por nome; exportação visual

**Animation:** Entrada das linhas com stagger (40ms), expansão de detalhes com accordion suave (220ms cubic-bezier), hover com elevação sutil de sombra

**Typography System:** Lora (serifado elegante) para títulos de seção e nome dos hormônios; Source Sans 3 (humanista, legível) para dados; Source Code Pro para valores técnicos
</text>
<probability>0.09</probability>
</response>

---

## Design Escolhido: "Enciclopédia Viva"

Filosofia: Interface que evoca a autoridade de uma enciclopédia científica clássica, mas com a interatividade e navegabilidade de uma aplicação web moderna. A tabela é o protagonista absoluto, apresentada como um mapa relacional do sistema endócrino humano.
