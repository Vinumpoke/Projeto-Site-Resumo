/**
 * Tabela Hormonal Interativa — Enciclopédia Viva
 * Design: Neoclassical Scientific Encyclopedia meets Interactive Web App
 * Paleta: creme/marfim (#FAFAF7), índigo (#3B3F8C), terracota (#C4622D),
 *         verde-azulado (#2A7A6F), violeta (#6B4FA0), azul-aço (#2C5F8A)
 * Tipografia: Lora (títulos serifados) + Source Sans 3 (corpo humanista)
 */

import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  ChevronDown,
  ChevronUp,
  X,
  BookOpen,
  FlaskConical,
  Activity,
  RefreshCw,
  Dna,
  Zap,
  TrendingDown,
} from "lucide-react";
import {
  hormones,
  sistemas,
  orgaos,
  searchHormones,
  type Hormone,
} from "@/data/hormones";

const BANNER_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663697163055/kqjueqr2K8WDaLfKcqqq9N/banner-hormonal-N98CpakSoUMTdVpAoEiGfY.webp";

// ─── Feedback badge ──────────────────────────────────────────────────────────
function FeedbackBadge({ type, text }: { type: "pos" | "neg"; text: string }) {
  const isPos = type === "pos";
  return (
    <div
      className={`flex items-start gap-2 rounded-lg px-3 py-2 text-xs leading-snug border ${
        isPos
          ? "bg-emerald-50 border-emerald-200 text-emerald-800"
          : "bg-rose-50 border-rose-200 text-rose-800"
      }`}
    >
      <span className="mt-0.5 shrink-0 font-bold text-base leading-none">
        {isPos ? "↻" : "↺"}
      </span>
      <div>
        <div className={`text-[10px] font-bold uppercase tracking-wider mb-0.5 ${isPos ? "text-emerald-600" : "text-rose-600"}`}>
          {isPos ? "Retroalimentação Positiva" : "Retroalimentação Negativa"}
        </div>
        <span>{text}</span>
      </div>
    </div>
  );
}

// ─── Effect cell ─────────────────────────────────────────────────────────────
function EffectCell({ value, color }: { value?: string; color: string }) {
  const hasEffect = value && !value.toLowerCase().startsWith("sem efeito");
  if (!hasEffect) {
    return <span className="text-stone-300 text-xs italic">—</span>;
  }
  return (
    <span className="text-stone-700 text-xs leading-relaxed">{value}</span>
  );
}

// ─── System badge ─────────────────────────────────────────────────────────────
function SystemBadge({ color, label }: { color: string; label: string }) {
  return (
    <span
      className="inline-flex items-center rounded-full px-2.5 py-1 text-[10px] font-bold tracking-wide uppercase text-white shadow-sm"
      style={{ backgroundColor: color }}
    >
      {label}
    </span>
  );
}

// ─── Organ dot indicators ─────────────────────────────────────────────────────
function OrganDots({ hormone }: { hormone: Hormone }) {
  return (
    <div className="flex items-center gap-0.5">
      {orgaos.map((o) => {
        const val = hormone.efeitos[o.id as keyof typeof hormone.efeitos];
        const has = val && !val.toLowerCase().startsWith("sem efeito");
        return (
          <span
            key={o.id}
            title={`${o.label}: ${has ? val : "Sem efeito direto"}`}
            className={`w-5 h-5 rounded-sm text-[10px] flex items-center justify-center transition-opacity ${
              has ? "opacity-100" : "opacity-20"
            }`}
            style={has ? { backgroundColor: hormone.sistemaColor + "20", color: hormone.sistemaColor } : { backgroundColor: "#f5f5f4" }}
          >
            {o.icon}
          </span>
        );
      })}
    </div>
  );
}

// ─── Expanded row detail ──────────────────────────────────────────────────────
function ExpandedDetail({ hormone }: { hormone: Hormone }) {
  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: "auto" }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.25, ease: [0.23, 1, 0.32, 1] }}
      className="overflow-hidden"
    >
      <div
        className="px-6 pb-6 pt-4 border-t"
        style={{
          background: `linear-gradient(to bottom, ${hormone.sistemaColor}08, transparent)`,
          borderTopColor: hormone.sistemaColor + "30",
        }}
      >
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5">
          {/* Síntese */}
          <div className="xl:col-span-1">
            <h4 className="text-[10px] font-bold uppercase tracking-[0.15em] mb-2 flex items-center gap-1.5" style={{ color: hormone.sistemaColor }}>
              <FlaskConical size={11} /> Síntese e Localização
            </h4>
            <p className="text-sm text-stone-700 leading-relaxed">{hormone.sintese}</p>
          </div>

          {/* Regulação */}
          <div className="xl:col-span-1">
            <h4 className="text-[10px] font-bold uppercase tracking-[0.15em] mb-2 flex items-center gap-1.5" style={{ color: hormone.sistemaColor }}>
              <Activity size={11} /> Regulação
            </h4>
            <div className="space-y-2.5">
              <div className="rounded-lg bg-emerald-50 border border-emerald-100 px-3 py-2">
                <div className="flex items-center gap-1 mb-1">
                  <Zap size={10} className="text-emerald-600" />
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">Estímulo</span>
                </div>
                <p className="text-xs text-stone-700 leading-relaxed">{hormone.estimulo}</p>
              </div>
              <div className="rounded-lg bg-rose-50 border border-rose-100 px-3 py-2">
                <div className="flex items-center gap-1 mb-1">
                  <TrendingDown size={10} className="text-rose-600" />
                  <span className="text-[10px] font-bold uppercase tracking-wider text-rose-700">Inibição</span>
                </div>
                <p className="text-xs text-stone-700 leading-relaxed">{hormone.inibicao}</p>
              </div>
            </div>
          </div>

          {/* Retroalimentação */}
          <div className="xl:col-span-1">
            <h4 className="text-[10px] font-bold uppercase tracking-[0.15em] mb-2 flex items-center gap-1.5" style={{ color: hormone.sistemaColor }}>
              <RefreshCw size={11} /> Retroalimentação
            </h4>
            <div className="space-y-2">
              <FeedbackBadge type="pos" text={hormone.feedbackPositivo} />
              <FeedbackBadge type="neg" text={hormone.feedbackNegativo} />
            </div>
          </div>

          {/* Efeitos biológicos */}
          <div className="xl:col-span-1">
            <h4 className="text-[10px] font-bold uppercase tracking-[0.15em] mb-2 flex items-center gap-1.5" style={{ color: hormone.sistemaColor }}>
              <Dna size={11} /> Efeitos por Tecido
            </h4>
            <div className="grid grid-cols-2 gap-1.5">
              {orgaos.map((orgao) => {
                const key = orgao.id as keyof typeof hormone.efeitos;
                const val = hormone.efeitos[key];
                const hasEffect = val && !val.toLowerCase().startsWith("sem efeito");
                return (
                  <div
                    key={orgao.id}
                    className={`rounded-md p-2 border text-left ${
                      hasEffect
                        ? "bg-white border-stone-200"
                        : "bg-stone-50/50 border-stone-100"
                    }`}
                  >
                    <div className="flex items-center gap-1 mb-0.5">
                      <span className="text-sm">{orgao.icon}</span>
                      <span className="text-[9px] font-bold uppercase tracking-wide text-stone-400">
                        {orgao.label}
                      </span>
                    </div>
                    <EffectCell value={val} color={hormone.sistemaColor} />
                  </div>
                );
              })}
            </div>
          </div>

          {/* Outros efeitos — full width */}
          {hormone.efeitos.outros && (
            <div className="xl:col-span-4 md:col-span-2">
              <div
                className="rounded-lg p-3 border"
                style={{ borderColor: hormone.sistemaColor + "30", backgroundColor: hormone.sistemaColor + "08" }}
              >
                <div className="text-[10px] font-bold uppercase tracking-wider mb-1" style={{ color: hormone.sistemaColor }}>
                  Outros Sistemas e Efeitos
                </div>
                <p className="text-xs text-stone-700 leading-relaxed">{hormone.efeitos.outros}</p>
              </div>
            </div>
          )}

          {hormone.nota && (
            <div className="xl:col-span-4 md:col-span-2 rounded-lg bg-amber-50 border border-amber-200 px-3 py-2">
              <span className="text-[10px] font-bold uppercase tracking-wide text-amber-700">⚠ Nota: </span>
              <span className="text-xs text-amber-800">{hormone.nota}</span>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

// ─── Table row ────────────────────────────────────────────────────────────────
function HormoneRow({
  hormone,
  index,
  isExpanded,
  onToggle,
}: {
  hormone: Hormone;
  index: number;
  isExpanded: boolean;
  onToggle: () => void;
}) {
  const sistema = sistemas.find((s) => s.id === hormone.sistema);

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.18, delay: Math.min(index * 0.02, 0.4), ease: [0.23, 1, 0.32, 1] }}
      className={`border-b border-stone-100 last:border-b-0 transition-colors duration-150 ${
        isExpanded ? "" : "hover:bg-stone-50/70"
      }`}
      style={isExpanded ? { backgroundColor: hormone.sistemaColor + "06" } : {}}
    >
      {/* Main row */}
      <button
        onClick={onToggle}
        className="w-full text-left px-4 sm:px-5 py-3.5 flex items-center gap-3 group"
      >
        {/* Index */}
        <span className="text-[11px] text-stone-300 font-mono w-6 shrink-0 text-right select-none">
          {String(index + 1).padStart(2, "0")}
        </span>

        {/* Left accent bar */}
        <div
          className="w-0.5 h-8 rounded-full shrink-0 transition-opacity duration-150"
          style={{
            backgroundColor: hormone.sistemaColor,
            opacity: isExpanded ? 1 : 0.25,
          }}
        />

        {/* Name & sigla */}
        <div className="flex-1 min-w-0">
          <div className="flex items-baseline gap-2 flex-wrap">
            <span
              className="font-semibold text-stone-800 text-sm leading-snug"
              style={{ fontFamily: "Lora, Georgia, serif" }}
            >
              {hormone.nome}
            </span>
            {hormone.sigla && (
              <span className="text-[10px] font-mono bg-stone-100 text-stone-500 px-1.5 py-0.5 rounded shrink-0">
                {hormone.sigla}
              </span>
            )}
          </div>
        </div>

        {/* System badge — hidden on mobile */}
        <div className="hidden sm:block shrink-0">
          <SystemBadge color={hormone.sistemaColor} label={sistema?.label || hormone.sistema} />
        </div>

        {/* Organ dots — hidden on small screens */}
        <div className="hidden lg:block shrink-0">
          <OrganDots hormone={hormone} />
        </div>

        {/* Feedback indicators */}
        <div className="hidden md:flex items-center gap-1 shrink-0">
          <span
            title="Retroalimentação Positiva"
            className="text-base font-bold transition-colors"
            style={{
              color:
                hormone.feedbackType === "positiva" || hormone.feedbackType === "ambas"
                  ? "#059669"
                  : "#d1d5db",
            }}
          >
            ↻
          </span>
          <span
            title="Retroalimentação Negativa"
            className="text-base font-bold transition-colors"
            style={{
              color:
                hormone.feedbackType === "negativa" || hormone.feedbackType === "ambas"
                  ? "#f43f5e"
                  : "#d1d5db",
            }}
          >
            ↺
          </span>
        </div>

        {/* Expand icon */}
        <div
          className="shrink-0 transition-colors duration-150"
          style={{ color: isExpanded ? hormone.sistemaColor : "#a8a29e" }}
        >
          {isExpanded ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
        </div>
      </button>

      {/* Expanded detail */}
      <AnimatePresence>
        {isExpanded && <ExpandedDetail hormone={hormone} />}
      </AnimatePresence>
    </motion.div>
  );
}

// ─── System section header ────────────────────────────────────────────────────
function SystemSectionHeader({ sistema, count }: { sistema: typeof sistemas[0]; count: number }) {
  return (
    <div
      className="flex items-center gap-3 px-5 py-2.5 border-b"
      style={{
        backgroundColor: sistema.color + "10",
        borderBottomColor: sistema.color + "30",
      }}
    >
      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: sistema.color }} />
      <span
        className="text-xs font-bold uppercase tracking-[0.15em]"
        style={{ color: sistema.color, fontFamily: "Source Sans 3, sans-serif" }}
      >
        {sistema.label}
      </span>
      <span className="text-xs text-stone-400 ml-auto">{count} hormônio{count !== 1 ? "s" : ""}</span>
    </div>
  );
}

// ─── Stats summary ────────────────────────────────────────────────────────────
function StatsSummary() {
  const withBothFeedback = hormones.filter((h) => h.feedbackType === "ambas").length;
  const withPosFeedback = hormones.filter((h) => h.feedbackType === "positiva" || h.feedbackType === "ambas").length;
  const withNegFeedback = hormones.filter((h) => h.feedbackType === "negativa" || h.feedbackType === "ambas").length;

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
      {[
        { label: "Total de Hormônios", value: hormones.length, color: "#44403c" },
        { label: "Com Retroalim. Positiva", value: withPosFeedback, color: "#059669" },
        { label: "Com Retroalim. Negativa", value: withNegFeedback, color: "#f43f5e" },
        { label: "Com Ambas", value: withBothFeedback, color: "#7c3aed" },
      ].map((stat) => (
        <div
          key={stat.label}
          className="bg-white rounded-xl border border-stone-200 px-4 py-3 shadow-sm"
        >
          <div
            className="text-2xl font-bold mb-0.5"
            style={{ fontFamily: "Lora, serif", color: stat.color }}
          >
            {stat.value}
          </div>
          <div className="text-[11px] text-stone-500 leading-tight">{stat.label}</div>
        </div>
      ))}
    </div>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────
export default function Home() {
  const [selectedSistema, setSelectedSistema] = useState("todos");
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [feedbackFilter, setFeedbackFilter] = useState<"todos" | "positiva" | "negativa" | "ambas">("todos");
  const [groupBySistema, setGroupBySistema] = useState(false);

  const filteredHormones = useMemo(() => {
    let result = searchQuery ? searchHormones(searchQuery) : hormones;
    if (selectedSistema !== "todos") {
      result = result.filter((h) => h.sistema === selectedSistema);
    }
    if (feedbackFilter !== "todos") {
      result = result.filter((h) => {
        if (feedbackFilter === "positiva") return h.feedbackType === "positiva" || h.feedbackType === "ambas";
        if (feedbackFilter === "negativa") return h.feedbackType === "negativa" || h.feedbackType === "ambas";
        if (feedbackFilter === "ambas") return h.feedbackType === "ambas";
        return true;
      });
    }
    return result;
  }, [selectedSistema, searchQuery, feedbackFilter]);

  // Group by system if enabled
  const groupedHormones = useMemo(() => {
    if (!groupBySistema) return null;
    const groups: Record<string, Hormone[]> = {};
    filteredHormones.forEach((h) => {
      if (!groups[h.sistema]) groups[h.sistema] = [];
      groups[h.sistema].push(h);
    });
    return groups;
  }, [filteredHormones, groupBySistema]);

  const handleToggle = (id: string) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  const clearFilters = () => {
    setSelectedSistema("todos");
    setSearchQuery("");
    setFeedbackFilter("todos");
    setExpandedId(null);
  };

  const hasFilters = selectedSistema !== "todos" || searchQuery || feedbackFilter !== "todos";

  let rowIndex = 0;

  return (
    <div className="min-h-screen" style={{ backgroundColor: "#FAFAF7", fontFamily: "Source Sans 3, sans-serif" }}>

      {/* ── Hero Banner ── */}
      <div className="relative overflow-hidden" style={{ height: "220px" }}>
        <img
          src={BANNER_URL}
          alt="Sistema Endócrino Humano — ilustração anatômica"
          className="w-full h-full object-cover object-center"
        />
        <div
          className="absolute inset-0"
          style={{
            background: "linear-gradient(to right, rgba(250,250,247,0.95) 0%, rgba(250,250,247,0.7) 40%, rgba(250,250,247,0.2) 70%, transparent 100%)",
          }}
        />
        <div className="absolute inset-0 flex items-center">
          <div className="max-w-7xl mx-auto px-6 w-full">
            <div className="flex items-center gap-2 mb-1">
              <BookOpen size={14} className="text-stone-400" />
              <span className="text-[11px] font-bold uppercase tracking-[0.25em] text-stone-400">
                Enciclopédia Hormonal
              </span>
            </div>
            <h1
              className="text-3xl sm:text-4xl font-bold text-stone-900 leading-tight mb-2"
              style={{ fontFamily: "Lora, Georgia, serif" }}
            >
              Sistema Endócrino Humano
            </h1>
            <p className="text-sm text-stone-600 max-w-lg leading-relaxed">
              Tabela sintética e relacional de todos os hormônios — síntese, localização, regulação, efeitos biológicos e retroalimentação.
            </p>
          </div>
        </div>
      </div>

      {/* ── Sticky controls ── */}
      <div
        className="sticky top-0 z-20 border-b border-stone-200 bg-white/95 backdrop-blur-sm shadow-sm"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3">
          {/* Search */}
          <div className="relative mb-3">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              placeholder="Buscar por nome, sigla ou tecido-alvo..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-sm rounded-lg border border-stone-200 bg-stone-50 text-stone-800 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-300 focus:bg-white transition-all"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600">
                <X size={13} />
              </button>
            )}
          </div>

          {/* Filter pills */}
          <div className="flex flex-wrap gap-1.5 items-center">
            {/* System filters */}
            {sistemas.map((s) => (
              <button
                key={s.id}
                onClick={() => setSelectedSistema(s.id)}
                className={`px-2.5 py-1 rounded-full text-[11px] font-bold transition-all duration-150 border ${
                  selectedSistema === s.id
                    ? "text-white border-transparent shadow-sm scale-105"
                    : "bg-white text-stone-500 border-stone-200 hover:border-stone-300 hover:text-stone-700"
                }`}
                style={selectedSistema === s.id ? { backgroundColor: s.color, borderColor: s.color } : {}}
              >
                {s.id === "todos" ? "Todos" : s.label}
              </button>
            ))}

            <span className="text-stone-200 hidden sm:block mx-1">|</span>

            {/* Feedback filters */}
            {[
              { id: "todos", label: "Qualquer FB" },
              { id: "positiva", label: "↻ Positiva", activeColor: "#059669" },
              { id: "negativa", label: "↺ Negativa", activeColor: "#f43f5e" },
              { id: "ambas", label: "↻↺ Ambas", activeColor: "#7c3aed" },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setFeedbackFilter(f.id as any)}
                className={`px-2.5 py-1 rounded-full text-[11px] font-bold transition-all duration-150 border ${
                  feedbackFilter === f.id
                    ? "text-white border-transparent shadow-sm"
                    : "bg-white text-stone-500 border-stone-200 hover:border-stone-300"
                }`}
                style={feedbackFilter === f.id && f.activeColor ? { backgroundColor: f.activeColor } : feedbackFilter === f.id ? { backgroundColor: "#44403c" } : {}}
              >
                {f.label}
              </button>
            ))}

            {/* Group toggle */}
            <button
              onClick={() => setGroupBySistema((v) => !v)}
              className={`ml-auto px-2.5 py-1 rounded-full text-[11px] font-bold transition-all duration-150 border ${
                groupBySistema
                  ? "bg-stone-700 text-white border-stone-700"
                  : "bg-white text-stone-500 border-stone-200 hover:border-stone-300"
              }`}
            >
              {groupBySistema ? "✓ Agrupado" : "Agrupar por sistema"}
            </button>

            {hasFilters && (
              <button
                onClick={clearFilters}
                className="flex items-center gap-1 text-[11px] text-stone-400 hover:text-stone-600 transition-colors px-2"
              >
                <X size={11} /> Limpar
              </button>
            )}
          </div>

          {/* Stats row */}
          <div className="flex flex-wrap items-center gap-3 mt-2 text-[11px] text-stone-400">
            <span>
              <strong className="text-stone-600">{filteredHormones.length}</strong> de{" "}
              <strong className="text-stone-600">{hormones.length}</strong> hormônios
            </span>
            <div className="hidden sm:flex flex-wrap gap-2">
              {sistemas.slice(1).map((s) => {
                const cnt = filteredHormones.filter((h) => h.sistema === s.id).length;
                if (cnt === 0) return null;
                return (
                  <span key={s.id} className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: s.color }} />
                    <span style={{ color: s.color }} className="font-semibold">{cnt}</span>
                  </span>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* ── Main content ── */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">

        {/* Stats summary */}
        {!hasFilters && !searchQuery && <StatsSummary />}

        {/* Legend */}
        <div className="flex flex-wrap gap-4 text-[11px] text-stone-400 mb-4 pb-3 border-b border-stone-100">
          <span className="flex items-center gap-1.5 font-semibold text-emerald-500">↻ Retroalimentação Positiva</span>
          <span className="flex items-center gap-1.5 font-semibold text-rose-400">↺ Retroalimentação Negativa</span>
          <span className="flex items-center gap-1.5 text-stone-300 font-medium">— Sem efeito direto documentado</span>
          <span className="flex items-center gap-1.5"><ChevronDown size={11} /> Clique para expandir detalhes</span>
        </div>

        {/* Column headers */}
        <div className="hidden lg:flex items-center gap-3 px-5 py-2 text-[10px] font-bold uppercase tracking-[0.15em] text-stone-400 border border-stone-200 rounded-t-xl bg-stone-50/80 border-b-0">
          <span className="w-6 text-right shrink-0">#</span>
          <span className="w-0.5 shrink-0" />
          <span className="flex-1">Hormônio / Sigla</span>
          <span className="w-44 shrink-0">Sistema</span>
          <span className="w-40 shrink-0">Órgãos-alvo</span>
          <span className="w-12 shrink-0 text-center">Feedback</span>
          <span className="w-5 shrink-0" />
        </div>

        {/* Table */}
        <div className={`bg-white border border-stone-200 overflow-hidden shadow-sm ${!groupBySistema ? "rounded-b-xl lg:rounded-t-none rounded-t-xl" : "rounded-xl"}`}>
          {filteredHormones.length === 0 ? (
            <div className="py-16 text-center text-stone-400">
              <Search size={28} className="mx-auto mb-3 opacity-30" />
              <p className="text-sm">Nenhum hormônio encontrado.</p>
              <button onClick={clearFilters} className="mt-2 text-xs underline hover:text-stone-600">
                Limpar filtros
              </button>
            </div>
          ) : groupBySistema && groupedHormones ? (
            // Grouped view
            Object.entries(groupedHormones).map(([sistemaId, sHormones]) => {
              const sistemaInfo = sistemas.find((s) => s.id === sistemaId);
              return (
                <div key={sistemaId}>
                  <SystemSectionHeader
                    sistema={sistemaInfo || { id: sistemaId, label: sistemaId, color: "#6B7280" }}
                    count={sHormones.length}
                  />
                  {sHormones.map((hormone, idx) => {
                    const globalIdx = rowIndex++;
                    return (
                      <HormoneRow
                        key={hormone.id}
                        hormone={hormone}
                        index={globalIdx}
                        isExpanded={expandedId === hormone.id}
                        onToggle={() => handleToggle(hormone.id)}
                      />
                    );
                  })}
                </div>
              );
            })
          ) : (
            // Flat view
            filteredHormones.map((hormone, index) => (
              <HormoneRow
                key={hormone.id}
                hormone={hormone}
                index={index}
                isExpanded={expandedId === hormone.id}
                onToggle={() => handleToggle(hormone.id)}
              />
            ))
          )}
        </div>

        {/* Footer */}
        <div className="mt-8 text-center">
          <div className="inline-flex items-center gap-2 text-xs text-stone-400 bg-white border border-stone-200 rounded-full px-4 py-2">
            <BookOpen size={11} />
            Baseado nos documentos APG e literatura fisiológica clássica (Guyton, Hall, Boron & Boulpaep)
          </div>
        </div>
      </div>
    </div>
  );
}
